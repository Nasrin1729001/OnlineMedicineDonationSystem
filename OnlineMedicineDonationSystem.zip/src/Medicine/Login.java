package Medicine;





import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.Border;


public class Login extends JFrame{
	JPanel panelLogin=new JPanel();
	JPanel panelContact =new JPanel();
	
	JPanel panelNorth=new JPanel();
	JPanel panelNorthNorth =new JPanel();
    JPanel panelNorthCenter = new JPanel();
	JPanel panelCenter=new JPanel();
   
	
	JLabel lblBackground=new JLabel(new ImageIcon("image/login.jpg"));
	
	JButton btnLogin =new JButton("Login");
	JButton btnExit =new JButton("Exit");
	JButton btnContact =new JButton("Contact");
	
	JButton btnHome = new JButton("Home");
	JButton btnAdmin = new JButton("Admin");
	JButton btnNGO = new JButton("NGO");
	JButton btnUser = new JButton("User");
	
	
	
	JLabel lblUsername= new JLabel("Username:");
	JTextField txtUsername=new JTextField(20);
    JLabel lblPassword= new JLabel("Password:");
	JTextField txtPassword=new JTextField(20);
	JLabel lblUserType =new JLabel("UserType:");
	String ara[]={"","Admin","Donor","NGO","Supplier"};
	JComboBox cmbUserType =new JComboBox(ara);
	
	
	
	Dimension screen= Toolkit.getDefaultToolkit().getScreenSize();
 public Login() {
	 init();
	 cmp();
	 btnAction();
 }
    private void loginAction() {

		panelLogin.setVisible(false);
		workingPanel wp = new workingPanel();
		add(wp);
		wp.setVisible(true);
		setSize(screen);
        setLocationRelativeTo(null);
    }
	
   /* private void contactAction() {
	   //panelContact.setVisible(false);
		contactPanel contact = new contactPanel();
		add(contact);
		//contact.setVisible(true);
		setSize(screen);
     setLocationRelativeTo(null);
 }*/
	private void btnAction() {
		btnLogin.addActionListener(new ActionListener() {			
			public void actionPerformed(ActionEvent arg0) {
				loginAction();
			}
		});
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				//dispose();
				System.exit(0);
			}
		});
		btnContact.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				//dispose();
				//contactAction();
			}
		});
		btnHome.addActionListener(new ActionListener() {			
			public void actionPerformed(ActionEvent arg0) {
				loginAction();
			}
		});
		btnAdmin.addActionListener(new ActionListener() {			
			public void actionPerformed(ActionEvent arg0) {
				loginAction();
			}
		});
		btnUser.addActionListener(new ActionListener() {			
			public void actionPerformed(ActionEvent arg0) {
				loginAction();
			}
		});
		btnNGO.addActionListener(new ActionListener() {			
			public void actionPerformed(ActionEvent arg0) {
				loginAction();
			}
		});
	}

private void cmp() {
	add(panelLogin);
	panelLogin.setLayout(new BorderLayout());
	panelLogin.add(panelNorth,BorderLayout.NORTH);
	panelLogin.add(panelCenter,BorderLayout.CENTER);
	
	
	panelNorthWork();
	panelCenterWork();
	
	//panelLogin. setBackground(Color.blue);
	
}

private void panelCenterWork() {
	
   panelCenter.setBorder(BorderFactory.createEmptyBorder());
   
		 panelCenter.setLayout(new FlowLayout());
	     panelCenter.add(btnLogin);
	     btnLogin.setPreferredSize(new Dimension(70,20));
	     panelCenter.add(btnExit);
	     btnExit.setPreferredSize(new Dimension(70,20));
	     panelCenter.add(btnContact);
	     btnContact.setPreferredSize(new Dimension(80,20));
	
}
private void panelNorthWork() {
	
	panelNorth.setLayout(new BorderLayout());
	panelNorth.setPreferredSize(new Dimension(0,300));
	panelNorth.add(panelNorthNorth,BorderLayout.NORTH);
	panelNorth.add(panelNorthCenter,BorderLayout.CENTER);
	
	panelNorthNorthWork();
	panelNorthCenterWork();
	
	//panelLogin. setBackground(Color.blue);
	
}
private void panelNorthCenterWork() {
	
	panelNorthCenter.setBorder(BorderFactory.createEmptyBorder());
	
	panelNorthCenter.add(lblBackground);
	GridBagLayout grid= new GridBagLayout();
	GridBagConstraints c= new GridBagConstraints();
	lblBackground.setLayout(grid);

	c.gridx = 0;
	c.gridy = 0;
	c.fill = GridBagConstraints.BOTH;
	c.insets = new Insets(5,5,5,5);
	lblBackground.add(lblUsername,c);
	lblUsername.setForeground(Color.WHITE);

	c.gridx = 1;
	c.gridy = 0;
	c.fill = GridBagConstraints.BOTH;
	c.insets = new Insets(5,5,5,5);
	lblBackground.add(txtUsername,c);

	c.gridx = 0;
	c.gridy = 1;
	c.fill = GridBagConstraints.BOTH;
	c.insets = new Insets(5,5,5,5);
	lblBackground.add(lblPassword,c);
	lblPassword.setForeground(Color.WHITE);
	
	c.gridx = 1;
	c.gridy = 1;
	c.fill = GridBagConstraints.BOTH;
	c.insets = new Insets(5,5,5,5);
	lblBackground.add(txtPassword,c);
	
	c.gridx = 0;
	c.gridy = 2;
	c.fill = GridBagConstraints.BOTH;
	c.insets = new Insets(5,5,5,5);
	lblBackground.add(lblUserType,c);
	lblUserType.setForeground(Color.WHITE);
	
	c.gridx = 1;
	c.gridy = 2;
	c.fill = GridBagConstraints.BOTH;
	c.insets = new Insets(5,5,5,5);
	lblBackground.add(cmbUserType,c);



}
	

private void panelNorthNorthWork() {
	panelNorthNorth.setBorder(BorderFactory.createLoweredSoftBevelBorder());
	panelNorthNorth.setPreferredSize(new Dimension(0,50));
	panelNorthNorth.setBorder(BorderFactory.createEmptyBorder());
	   
	panelNorthNorth.setLayout(new GridLayout());
	panelNorthNorth.add(btnHome);
     
     panelNorthNorth.add(btnAdmin);
     
     panelNorthNorth.add(btnNGO);
  
     panelNorthNorth.add(btnUser);
   

	
}
private void init() {
	setSize(600,400);
	setVisible(true);
	setLocationRelativeTo(null);
	setTitle("OnlineMedicineDonation");
	setResizable(false);
	
}
}
