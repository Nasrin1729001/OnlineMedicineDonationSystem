package Medicine;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.util.Scanner;
import java.util.StringTokenizer;

public class DbConnection {
	public static Connection con=null;
	public static Statement sta=null;
	public static void connect() {
		try {
			File file=new File("src/dbConnection.txt");
			Scanner scan=new Scanner(file);
			int a=1;
			String server="",port="",username="",password="",database="";
			while(scan.hasNextLine()) 
			{
				String s=scan.nextLine();
				StringTokenizer token=new StringTokenizer(s);
				token.nextToken();
				
				String secondToken=token.nextToken();
				if(a==1) {
					server=secondToken;
				}
				else if(a==2) {
					port=secondToken;
				}
				else if(a==3) {
					username=secondToken;
				}
				else if(a==4) {
					database=secondToken;
					break;
				}
				a++;
			}
			String url="jdbc:mysql://"+server+":"+port+"/"+database;
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			con=DriverManager.getConnection(url,username,password);
			sta=con.createStatement();
			System.out.println("Ok Done");
		}
		catch(Exception exp) {
			System.out.println(exp);
		}
	}
}
