package Medicine;

import Medicine.DbConnection;
import Medicine.Login;

public class Main {
	public static void main(String args[]){
		DbConnection.connect();
		Login lg=new Login();
	}

}
