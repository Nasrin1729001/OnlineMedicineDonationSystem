package Medicine;


import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import com.toedter.calendar.JDateChooser;



public class Admin extends JPanel{

	JPanel panelCenter= new JPanel();
	JPanel panelEast =new JPanel();

	JPanel panelCenterNorth=new JPanel();
	JPanel panelCenterSouth =new JPanel();
	JPanel panelCenterCenter=new JPanel();
    
	JPanel panelEastSouth=new JPanel();
	JPanel panelEastNorth=new JPanel();
	JPanel panelEastCenter=new JPanel();
	
	JLabel lblRegistration =new JLabel("Registration For New User");

	JButton btnAdd=new JButton("Add");
	JButton btnRefresh=new JButton("Refresh");
	JButton btnDelete=new JButton("Delete");
    
	JLabel lblDonor = new JLabel("Donate Here");
	JLabel lblUserName=new JLabel("User Name");
	JTextField txtUserName =new JTextField(50);
	
	JLabel lblUserType=new JLabel("User Type");
	String ara[]={"Donor","NGO","Supplier"};
	JComboBox cmbUserType =new JComboBox(ara);
	

	JLabel lblMail=new JLabel("Mail");
	JTextField txtMail= new JTextField(20);

	JLabel lblContact=new JLabel("Contact");
	JTextField txtContact=new JTextField(20);
	
	JLabel lblDate=new JLabel("Date");
	JDateChooser txtDate= new JDateChooser();

	
	JLabel lblSearch=new JLabel("Search");
	SuggestText cmbSearch=new SuggestText();
	
	JButton btnNGO=new JButton("NGO");
	JButton btnSupplier=new JButton("Supplier");
	JButton btnDonor=new JButton("Donor");
	JButton btnMedicine=new JButton("Medicine");
	
	SimpleDateFormat dateFormatSql= new SimpleDateFormat("yyyy-MM-dd");


	public Admin(){
		//setBackground(Color.blue);
		setPreferredSize(new Dimension(1150,730));
		setLayout(new GridLayout(1, 0,10,10));
		add(panelCenter);
		add(panelEast);
		panelCenterWork();
		panelEastWork();

	}

	private void panelEastWork(){

		panelEast.setBorder(BorderFactory.createRaisedSoftBevelBorder());
		panelEast.setLayout(new BorderLayout());
		panelEast.add(panelEastSouth,BorderLayout.SOUTH);
		panelEast.add(panelEastNorth,BorderLayout.NORTH);
		panelEast.add(panelEastCenter,BorderLayout.CENTER);

		panelEastSouthWork();
		panelEastCenterWork();
		panelEastNorthWork();
	}

	private void panelEastNorthWork() {
		panelEastNorth.setBorder(BorderFactory.createRaisedSoftBevelBorder());
		panelEastNorth.setPreferredSize(new Dimension(0,100));
		panelEastNorth.add(lblSearch);
		panelEastNorth.add(cmbSearch.cmbSuggest);
		
		cmbSearch.cmbSuggest.setPreferredSize(new Dimension(200,25));
		FlowLayout flow = new FlowLayout();
		panelEastNorth.setLayout(flow);
	}

	private void panelEastCenterWork() {
		panelEastCenter.setBorder(BorderFactory.createRaisedSoftBevelBorder());
		panelEastCenter.setBorder(BorderFactory.createRaisedSoftBevelBorder());
		panelEastCenter.setPreferredSize(new Dimension(0,150));
		GridLayout grid=new GridLayout();
		panelEastCenter.setLayout(grid);
		panelEastCenter.add(btnNGO);
		panelEastCenter.add(btnSupplier);
		panelEastCenter.add(btnDonor);
		panelEastCenter.add(btnMedicine);
	}

	private void panelEastSouthWork() {
		panelEastSouth.setBorder(BorderFactory.createRaisedSoftBevelBorder());
		panelEastSouth.setPreferredSize(new Dimension(0,550));
		
	}

	private void panelCenterWork() {
		panelCenter.setBorder(BorderFactory.createLoweredSoftBevelBorder());
		panelCenter.setLayout(new BorderLayout());
		panelCenter.add(panelCenterNorth,BorderLayout.NORTH);
		panelCenter.add(panelCenterSouth,BorderLayout.SOUTH);
		panelCenter.add(panelCenterCenter,BorderLayout.CENTER);

		panelCenterNorthWork();
		panelCenterSouthWork();
		panelCenterCenterWork();


	}

	private void panelCenterSouthWork() {
		
		panelCenterSouth.setBorder(BorderFactory.createRaisedSoftBevelBorder());
		panelCenterSouth.setPreferredSize(new Dimension(0,150));
		FlowLayout flow=new FlowLayout();
		panelCenterSouth.setLayout(flow);
		panelCenterSouth.add(btnAdd);
		panelCenterSouth.add(btnRefresh);
		panelCenterSouth.add(btnDelete);
	}

	private void panelCenterCenterWork() {
		panelCenterCenter.setBorder(BorderFactory.createRaisedSoftBevelBorder());
		GridBagConstraints c= new GridBagConstraints();
		panelCenterCenter.setLayout(new GridBagLayout());
        
		
		c.gridx=0;
		c.gridy=0;
		c.fill=GridBagConstraints.BOTH;
		c.insets=new Insets(5,5,5,5);
		panelCenterCenter.add(lblUserName,c);

		c.gridx=1;
		c.gridy=0;
		c.fill=GridBagConstraints.BOTH;
		c.insets=new Insets(5,5,5,5);
		panelCenterCenter.add(txtUserName,c);
		

		c.gridx=0;
		c.gridy=1;
		c.fill=GridBagConstraints.BOTH;
		c.insets=new Insets(5, 5, 5, 5);
		panelCenterCenter.add(lblUserType,c);

		c.gridx=1;
		c.gridy=1;
		c.fill=GridBagConstraints.BOTH;
		c.insets=new Insets(5, 5, 5, 5);
		panelCenterCenter.add(cmbUserType,c);



		c.gridx=0;
		c.gridy=2;
		c.fill=GridBagConstraints.BOTH;
		c.insets=new Insets(5, 5, 5, 5);
		panelCenterCenter.add(lblMail,c);

		c.gridx=1;
		c.gridy=2;
		c.fill=GridBagConstraints.BOTH;
		c.insets=new Insets(5, 5, 5, 5);
		panelCenterCenter.add(txtMail,c);

     	c.gridx=0;
		c.gridy=3;
		c.fill=GridBagConstraints.BOTH;
		c.insets=new Insets(5, 5, 5, 5);
		panelCenterCenter.add(lblContact,c);

		c.gridx=1;
		c.gridy=3;
		c.fill=GridBagConstraints.BOTH;
		c.insets=new Insets(5, 5, 5, 5);
		panelCenterCenter.add(txtContact,c);

		c.gridx=0;
		c.gridy=4;
		c.fill=GridBagConstraints.BOTH;
		c.insets=new Insets(5, 5, 5, 5);
		panelCenterCenter.add(lblDate,c);

		c.gridx=1;
		c.gridy=4;
		c.fill=GridBagConstraints.BOTH;
		c.insets=new Insets(5, 5, 5, 5);
		panelCenterCenter.add(txtDate,c);
		txtDate.setDateFormatString("dd-MM-yyyy");
		txtDate.setDate(new Date());

		
	}

	private void panelCenterNorthWork() {
		panelCenterNorth.setBorder(BorderFactory.createRaisedSoftBevelBorder());
		panelCenterNorth.setPreferredSize(new Dimension(0,150));
        panelCenterNorth.add(lblRegistration);
        lblRegistration.setPreferredSize(new Dimension(200,150));
      }

}
