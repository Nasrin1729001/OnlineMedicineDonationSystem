package Medicine;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import com.toedter.calendar.JDateChooser;



public class Donor extends JPanel{

	JPanel panelCenter= new JPanel();
	JPanel panelEast =new JPanel();

	JPanel panelCenterNorth=new JPanel();
	JPanel panelCenterCenter=new JPanel();
    
	JPanel panelEastSouth=new JPanel();
	JPanel panelEastNorth=new JPanel();
	JPanel panelEastCenter=new JPanel();

	JButton btnDonate=new JButton("Donate");
	JButton btnRefresh=new JButton("Refresh");
	JButton btnDelete=new JButton("Delete");
	
	JButton btnNGO=new JButton("NGO");
	JButton btnSupplier=new JButton("Supplier");
	JButton btnDonor=new JButton("Donor");
	JButton btnMedicine=new JButton("Medicine");

	JLabel lblUserName=new JLabel("User Name:");
	JTextField txtUserName=new JTextField(20);

	JLabel lblDate=new JLabel("Date:");
	JDateChooser txtDate= new JDateChooser();
    
	JLabel lblMed=new JLabel("Medicinine Name:");
	JTextField txtMed=new JTextField(20);
	
	JLabel lblDateExp=new JLabel("Exp. Date:");
	JDateChooser txtDateExp= new JDateChooser();

	JLabel lblQtyOfMed=new JLabel("Qty Of Medicine:");
	JTextField txtQtyOfMed=new JTextField(20);
	
	JLabel lblSearch=new JLabel("Search");
	SuggestText cmbSearch=new SuggestText();
	
	SimpleDateFormat dateFormatSql= new SimpleDateFormat("yyyy-MM-dd");


	public Donor(){
		//setBackground(Color.blue);
		setPreferredSize(new Dimension(1150,730));
		setLayout(new GridLayout(1, 0,10,10));
		add(panelCenter);
		add(panelEast);
		panelCenterWork();
		panelEastWork();

	}

	private void panelEastWork(){

		panelEast.setBorder(BorderFactory.createRaisedSoftBevelBorder());
		panelEast.setLayout(new BorderLayout());
		panelEast.add(panelEastSouth,BorderLayout.SOUTH);
		panelEast.add(panelEastNorth,BorderLayout.NORTH);
		panelEast.add(panelEastCenter,BorderLayout.CENTER);

		panelEastSouthWork();
		panelEastCenterWork();
		panelEastNorthWork();
	}

	private void panelEastNorthWork() {
		panelEastNorth.setBorder(BorderFactory.createRaisedSoftBevelBorder());
		panelEastNorth.setPreferredSize(new Dimension(0,100));
		panelEastNorth.add(lblSearch);
		panelEastNorth.add(cmbSearch.cmbSuggest);
		
		cmbSearch.cmbSuggest.setPreferredSize(new Dimension(200,25));
		FlowLayout flow = new FlowLayout();
		panelEastNorth.setLayout(flow);
	}

	private void panelEastCenterWork() {
		panelEastCenter.setBorder(BorderFactory.createRaisedSoftBevelBorder());
		panelEastCenter.setBorder(BorderFactory.createRaisedSoftBevelBorder());
		panelEastCenter.setPreferredSize(new Dimension(0,150));
		GridLayout grid=new GridLayout();
		panelEastCenter.setLayout(grid);
		panelEastCenter.add(btnNGO);
		panelEastCenter.add(btnSupplier);
		panelEastCenter.add(btnMedicine);
	}

	private void panelEastSouthWork() {
		panelEastSouth.setBorder(BorderFactory.createRaisedSoftBevelBorder());
		panelEastSouth.setPreferredSize(new Dimension(0,550));
		
	}

	private void panelCenterWork() {
		panelCenter.setBorder(BorderFactory.createLoweredSoftBevelBorder());
		panelCenter.setLayout(new BorderLayout());
		panelCenter.add(panelCenterNorth,BorderLayout.NORTH);
		panelCenter.add(panelCenterCenter,BorderLayout.CENTER);

		panelCenterNorthWork();
		panelCenterCenterWork();


	}

	private void panelCenterCenterWork() {
		panelCenterCenter.setBorder(BorderFactory.createRaisedSoftBevelBorder());
		FlowLayout flow=new FlowLayout();
		panelCenterCenter.setLayout(flow);
		panelCenterCenter.add(btnDonate);
		panelCenterCenter.add(btnRefresh);
		panelCenterCenter.add(btnDelete);
	}

	private void panelCenterNorthWork() {
		panelCenterNorth.setBorder(BorderFactory.createRaisedSoftBevelBorder());
		panelCenterNorth.setPreferredSize(new Dimension(0,650));
		GridBagConstraints c= new GridBagConstraints();
		panelCenterNorth.setLayout(new GridBagLayout());
        
		
		c.gridx=0;
		c.gridy=0;
		c.fill=GridBagConstraints.BOTH;
		c.insets=new Insets(5,5,5,5);
		panelCenterNorth.add(lblUserName,c);

		c.gridx=1;
		c.gridy=0;
		c.fill=GridBagConstraints.BOTH;
		c.insets=new Insets(5,5,5,5);
		panelCenterNorth.add(txtUserName,c);
		

		c.gridx=0;
		c.gridy=1;
		c.fill=GridBagConstraints.BOTH;
		c.insets=new Insets(5, 5, 5, 5);
		panelCenterNorth.add(lblMed,c);

		c.gridx=1;
		c.gridy=1;
		c.fill=GridBagConstraints.BOTH;
		c.insets=new Insets(5, 5, 5, 5);
		panelCenterNorth.add(txtMed,c);
		

		c.gridx=0;
		c.gridy=2;
		c.fill=GridBagConstraints.BOTH;
		c.insets=new Insets(5, 5, 5, 5);
		panelCenterNorth.add(lblQtyOfMed,c);

		c.gridx=1;
		c.gridy=2;
		c.fill=GridBagConstraints.BOTH;
		c.insets=new Insets(5, 5, 5, 5);
		panelCenterNorth.add(txtQtyOfMed,c);

     	c.gridx=0;
		c.gridy=3;
		c.fill=GridBagConstraints.BOTH;
		c.insets=new Insets(5, 5, 5, 5);
		panelCenterNorth.add(lblDateExp,c);

		c.gridx=1;
		c.gridy=3;
		c.fill=GridBagConstraints.BOTH;
		c.insets=new Insets(5, 5, 5, 5);
		panelCenterNorth.add(txtDateExp,c);
		txtDate.setDateFormatString("dd-MM-yyyy");
		txtDate.setDate(new Date());
   }

}
