package Medicine;


import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class workingPanel extends JPanel{
	JPanel panelWest=new JPanel();
	JPanel panelCenter=new JPanel();

	JButton btnAdmin=new JButton(new ImageIcon("image/admin.jpg"));
	JLabel  lblAdmin=new JLabel("Admin");


	JButton btnDonor=new JButton(new ImageIcon("image/donor.png"));
	JLabel  lblDonor=new JLabel("Donor");

	JButton btnNGO=new JButton(new ImageIcon("image/ngo.jpg"));
	JLabel  lblNGO=new JLabel("NGO");
	
	JButton btnSupplier=new JButton(new ImageIcon("image/supplier.png"));
	JLabel  lblSupplier=new JLabel("Supplier");

	JPanel panelAdmin =new JPanel();
	JPanel panelDonor=new JPanel();
	JPanel panelNGO=new JPanel();
    JPanel panelSupplier = new JPanel();
    
    Admin admin = new Admin();
	Donor donor=new Donor();
	NGO ngo=new NGO();
    Supplier supplier =new Supplier();
	
	public workingPanel(){
		//setBackground(Color.green);
		setLayout(new BorderLayout());
		add(panelWest,BorderLayout.WEST);
		add(panelCenter,BorderLayout.CENTER);
		panelCenterWork();
		panelWestWork();
		btnAction();

	}
	private void sidePanelTrueFalse(){
		panelAdmin.setVisible(false);
		panelDonor.setVisible(false);
		panelNGO.setVisible(false);
		panelSupplier.setVisible(false);
	}
	
	
	private void btnAction() {
		
		btnAdmin.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent arg0){
				sidePanelTrueFalse();
				panelAdmin.setVisible(true);

			}
		});
		btnDonor.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent arg0){
				sidePanelTrueFalse();
				panelDonor.setVisible(true);

			}
		});
		btnNGO.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent arg0){
				sidePanelTrueFalse();
				panelNGO.setVisible(true);
			}
		});

		btnSupplier.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent arg0){
				sidePanelTrueFalse();
				panelSupplier.setVisible(true);
			}
		});

	}

	private void panelWestWork() {
		panelWest.setBorder(BorderFactory.createLoweredSoftBevelBorder());
		panelWest.setPreferredSize(new Dimension(250,0));
		GridBagLayout grid= new GridBagLayout();
		GridBagConstraints c= new GridBagConstraints();
		panelWest.setLayout(grid);

		c.gridx = 0;
		c.gridy = 0;
		c.fill = GridBagConstraints.BOTH;
		c.insets = new Insets(4,4,4,4);
		panelWest.add(btnAdmin,c);

	   c.gridx = 0;
	    c.gridy = 1;
		c.fill = GridBagConstraints.BOTH;
		c.insets = new Insets(4,4,4,4);
		panelWest.add(lblAdmin,c);

		c.gridx = 0;
		c.gridy = 2;
		c.fill = GridBagConstraints.BOTH;
		c.insets = new Insets(5,5,5,5);
		panelWest.add(btnNGO,c);

    c.gridx = 0;
	c.gridy = 3;
	c.fill = GridBagConstraints.BOTH;
	c.insets = new Insets(5,5,5,5);
	panelWest.add(lblNGO,c);


		c.gridx = 0;
		c.gridy = 4;
		c.fill = GridBagConstraints.BOTH;
		c.insets = new Insets(5,5,5,5);
		panelWest.add(btnSupplier,c);

	c.gridx = 0;
	c.gridy = 5;
	c.fill = GridBagConstraints.BOTH;
	c.insets = new Insets(5,5,5,5);
	panelWest.add(lblSupplier,c);

		c.gridx = 0;
		c.gridy = 6;
		c.fill = GridBagConstraints.BOTH;
		c.insets = new Insets(5,5,5,5);
		panelWest.add(btnDonor,c);

	c.gridx = 0;
	c.gridy = 7;
	c.fill = GridBagConstraints.BOTH;
	c.insets = new Insets(5,5,5,5);
 panelWest.add(lblDonor,c);

	}

	private void panelCenterWork() {
		panelCenter.setBorder(BorderFactory.createRaisedSoftBevelBorder());
		FlowLayout flow=new FlowLayout();
		panelCenter.setLayout(flow);
		panelCenter.add(panelAdmin);
		panelCenter.add(panelDonor);
		panelCenter.add(panelNGO);
		panelCenter.add(panelSupplier);
		panelNGOWork();
		panelDonorWork();
		panelSupplierWork();
		panelAdminWork();
		panelCenter.add(btnAdmin);
		panelCenter.add(btnDonor);
		panelCenter.add(btnNGO);
		panelCenter.add(btnSupplier);
	}
	private void panelAdminWork() {
		panelAdmin.add(admin);

	}
	private void panelDonorWork() {
		panelDonor.add(donor);

	}
	private void panelNGOWork() {
		//panelPatient.setBackground(Color.blue);
		panelNGO.add(ngo);
	}
	private void panelSupplierWork() {
		//panelDonor.setBackground(Color.magenta);

		panelSupplier.add(supplier);

	}

}
